function varargout = Panel_Seleccion(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Panel_Seleccion_OpeningFcn, ...
                   'gui_OutputFcn',  @Panel_Seleccion_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Panel_Seleccion is made visible.
function Panel_Seleccion_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Panel_Seleccion (see VARARGIN)

% Choose default command line output for Panel_Seleccion
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Panel_Seleccion wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Panel_Seleccion_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in select.
function select_Callback(hObject, eventdata, handles)
% hObject    handle to select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[nom dir] = uigetfile({'*.mat'},'File Selector'); %Exploraci�n de archivos y formatos disponibles
if nom == 0
    return
end 
load(fullfile(dir,nom));
x1 = val(1,:);                  %Se�al ECG seleccionada
t1 = 0:0.00277:9.96923;         %Vector de tiempo

% nbits=8;                        %N�mero de bits de cuantizaci�n
% nint=2^nbits;                   %Niveles de cuantizaci�n
% a=2*2500/nint;                  %Maximo niveles de cuatizaci�n
% partition = [-2500+a:a:2500-a];
% codebook = [-2500+a/2:a:2500-a/2];
% [index,xq,distor] = quantiz(x1,partition,codebook);
set(handles.pop1,'string',seriallist)
nbits=8;                          %N�mero de bits de cuantizaci�n
nint=2^nbits;                     %Niveles de cuantizaci�n
a=(1100)/(nint-1);                  %Maximo niveles de cuatizaci�n
partition = [-650:a:450];                  %Longitud nint-1 para representar nint intervalos512
codebook = [0:1:nint];               %Longitud nint, una entrada para cada intervalo
[index,xq,distor] = quantiz(x1/1000,partition/1000,codebook);

global transmitir 
transmitir = index;

%Impresi�n de la se�al ECG seleccionada y cuantizada
axes(handles.ECG) 
plot(t1,x1,'b');     
title("Se�al Real");

axes(handles.ECG1) 
plot(t1,xq,'r');
title("Se�al Cuantizada");



% --- Executes on button press in Transmision.
function Transmision_Callback(hObject, eventdata, handles)
% hObject    handle to Transmision (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global transmitir 
disp('Inicio de la transmisi�n')

%Configuraci�n del puerto serial
id_co = get(handles.pop1,'string');
SerPIC= serial(id_co);
set(SerPIC,'BaudRate',9600);
set(SerPIC,'DataBits',8);
set(SerPIC,'Parity','none');
set(SerPIC,'StopBits',1);
set(SerPIC,'FlowControl','none');
fopen(SerPIC);

%Transmisi�n de la se�al seleccionada
for n = transmitir
    fprintf(SerPIC,'%s',n);pause(0.003)
end

%Cerrado del puerto
fclose(SerPIC);
delete(SerPIC)
clear SerPIC
disp('Detener')



function id_com_Callback(hObject, eventdata, handles)
% hObject    handle to id_com (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of id_com as text
%        str2double(get(hObject,'String')) returns contents of id_com as a double


% --- Executes during object creation, after setting all properties.
function id_com_CreateFcn(hObject, eventdata, handles)
% hObject    handle to id_com (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pop1.
function pop1_Callback(hObject, eventdata, handles)
% hObject    handle to pop1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop1


% --- Executes during object creation, after setting all properties.
function pop1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
