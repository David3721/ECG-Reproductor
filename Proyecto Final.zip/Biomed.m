pkg load communications
pkg load instrument-control





pkg load communications
pkg load instrument-control

[nom dir] = uigetfile({'*.mat'},'File Selector'); %Exploraci�n de archivos y formatos disponibles
if nom == 0
    return
end 
load(fullfile(dir,nom));
x = val(1,:);                     %Se�al ECG seleccionada
max(x)
min(x)

t1 = 0:0.00277:9.96923;           %Vector de tiempo
nbits=8;                          %N�mero de bits de cuantizaci�n
nint=2^nbits;                     %Niveles de cuantizaci�n
a=(1100)/(nint-1);                  %Maximo niveles de cuatizaci�n
partition = [-650:a:450];                  %Longitud nint-1 para representar nint intervalos512
codebook = [0:1:nint-1];               %Longitud nint, una entrada para cada intervalo
[index,xq,distor] = quantiz(x/1000,partition/1000,codebook);
transmitir = index;
subplot(2,1,1)
plot(t1,x/1000,'b');
subplot(2,1,2)
plot(t1,xq,'r');
flag=1;
disp('Inicio de la transmisi�n')
SerPIC=serial("\\\\.\\COM8",9600);

%set(SerPIC,'baudrate',19200);

for n =transmitir
  srl_write(SerPIC,uint8(n));pause(0.003)
end
fclose(SerPIC);
clear SerPIC
disp('Detener')